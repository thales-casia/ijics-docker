-- Adminer 4.8.1 PostgreSQL 15.2 (Debian 15.2-1.pgdg110+1) dump

DROP TABLE IF EXISTS "about";
DROP SEQUENCE IF EXISTS about_id_seq;
CREATE SEQUENCE about_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."about" (
    "id" integer DEFAULT nextval('about_id_seq') NOT NULL,
    "title" text NOT NULL,
    "content" text NOT NULL,
    "key" character varying(100) NOT NULL,
    "updated_at" timestamp DEFAULT now(),
    "created_at" timestamp DEFAULT now() NOT NULL,
    CONSTRAINT "about_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

COMMENT ON TABLE "public"."about" IS '常用数据';

COMMENT ON COLUMN "public"."about"."title" IS '标题';

COMMENT ON COLUMN "public"."about"."content" IS '内容';

COMMENT ON COLUMN "public"."about"."key" IS '查询索引';

COMMENT ON COLUMN "public"."about"."updated_at" IS '修改时间';

COMMENT ON COLUMN "public"."about"."created_at" IS '创建时间';

INSERT INTO "about" ("id", "title", "content", "key", "updated_at", "created_at") VALUES
(5,	'Contact',	'<p>E-mail: <a href="mailto:info@agist.org">info@agist.org</a>&nbsp;Tel. 732 543 6103</p>
<p>Address: 1900 Camden Ave, San Jose, CA 95124, US</p>',	'contact',	NULL,	'2023-03-02 12:32:27.98228'),
(8,	'Become a Reviewer',	'Become a Reviewer',	'reviewer',	NULL,	'2023-03-02 12:38:25.778499'),
(9,	'Open Access Publishing Options',	'Open Access Publishing Options',	'access',	NULL,	'2023-03-02 12:41:17.559775'),
(10,	'Submit Manuscript',	'Submit Manuscript',	'submit',	NULL,	'2023-03-02 12:42:55.466575'),
(3,	'Amis and Scope',	'<p>
The Journal of Cyber-Physical-Social Intelligence publishes studies on cross-cutting, fundamental scientific research and engineering development that underpin the integration of cyber, physical, and social elements across all application domains. The journal emphasizes advancements in automation and autonomy achieved through incorporating artificial intelligence into cyber-physical-social systems to enhance the seamless integration of physical components and computation with human-in- or human-on-the-loop.
</p>',	'amis-and-scope',	NULL,	'2023-02-28 09:25:31.493757'),
(6,	'Current Editorial Board',	'<h3>Editor-in-Chief</h3>
<p>Fei-Yue Wang and Robert Kozma </p>

<h3>Executive Editor-in-Chief</h3>
<p>Ying (Gina) Tang</p>

<h3>Associate Editors</h3>
<table width="100%">
<tr>
<td>Hui Yu (UK)</td>
<td>Maria Pia Fanti (Italy)</td>
<td>David Kaber (USA)</td>
</tr>
<tr>
<td>Lingxi Li (USA)</td>
<td>Mounîm A. EL YACOUBI (FR)</td>
<td>Xiwang Guo (CHINA)</td>
</tr>
<tr>
<td>Jay wang (USA)</td>
<td>YangQuan Chen (USA)</td>
<td>Jun Wang (CHINA)</td>
</tr>
<tr>
<td>Yan Wan (USA)</td>
<td>Rui Qin (CHINA)</td>
<td>Houshang Darabi (USA)</td>
</tr>
<tr>
<td>Zhi Wei (USA)</td>
<td>Jie Li (USA)</td>
<td>Bo Li (CHINA)</td>
</tr>
</table>
',	'editorial-board',	NULL,	'2023-03-02 12:34:55.367309'),
(4,	'Process for Submission',	'<p>All prospective authors must submit their manuscripts electronically. DOC or PDF files can be accepted and PDF files are preferred. Submitted manuscripts may be of three basic types: Reviews, Papers, and Letters.</p>
<p>The type "Review" includes review, survey, and tutorial. When submitting Review, please include a cover letter with the following information:</p>
<ol>
<li>Description of topic and its importance, including the contribution of this review to the Community and the distinction in this review with respect to the state-of-the-art review (if any);</li>
<li>Brief biography of the author(s) who contribute(s) most on this review to highlight the qualifications for writing reviews. Previously published representative reviews and articles of the author(s) can be attached as references;</li>
<li>Background records that extend beyond author’s own work to demonstrate the appeal of the topic to a broad audience.</li>
<li>Generally, the Review should be no more than 15 pages (mainbody without the list of references) and References no more than 150 items.</li>
</ol>
<p></p>
<p>Your file should be submitted according to the following procedure:</p>
<ol>
<li>Please go to: <a href="http://www.j-cpsi.com/user/me">http://www.j-cpsi.com/user/me</a> and follow the instructions to upload your file. You should register a new account for the first submission.</li>
<li>Sign the Transfer of Copyright Agreement.</li>
<li>The author will receive an e-mail message acknowledging successful reception of the submission and assigning a reference number to the submission.</li>
<li>The author can inquire about the review status through email. If the manuscript needs some modification, the author will be informed by email.</li>
</ol>
<p></p>
<p>Download the template:</p>
<ul>
<li><a href="http://cdn.j-cpsi.com/template.docx" target="_blank">Word</a></li>
<li><a href="http://cdn.j-cpsi.com/template.zip" target="_blank">LaTex</a></li>
</ul>',	'submission',	NULL,	'2023-03-01 06:38:26.766454'),
(7,	'Information for Authors',	'<h3>Manuscript Requirements</h3>
<p>Manuscripts submitted to this journal should adhere to the following guidelines. They should not have been published previously and should not be submitted or published elsewhere, either in English or any other languages, without the written consent of the publisher.</p>
<p>The contributed manuscripts should reflect the latest developments in the research area, emphasizing academic novelty, thoughtfulness, and practicability. It is important to highlight the main points while minimizing or eliminating dull narration and ordinary derivation as much as possible. Repetition of statements should be avoided across the Abstract, Introduction, and Conclusions sections.</p>
<p>The manuscripts should be formatted in a 2-column layout. The writing style should be simple and straightforward, while maintaining reliable data. Excessive self-appraisal must be avoided. Manuscripts of low quality, poor English writing, or with excessive quotations will be rejected without review.</p>
<h3>Process for Submission</h3>
<p>All prospective authors are required to submit their manuscripts electronically. We accept DOC or PDF files, although PDF files are preferred. Submitted manuscripts can fall into one of three basic types: Reviews, Papers, and Letters.</p>
<p>The "Review" category includes reviews, surveys, and tutorials. When submitting a Review, please include a cover letter containing the following information:</p>
<ol>
<li>A description of the topic''s importance, including the contribution this review makes to the community and its distinction from existing state-of-the-art reviews (if any).</li>
<li>A brief biography of the author(s) who contributed most to this review, highlighting their qualifications for writing reviews. Previously published representative reviews and articles by the author(s) can be attached as references.</li>
<li>Background records that extend beyond the author''s own work to demonstrate the topic''s appeal to a broad audience.</li>
<li>Generally, the Review should not exceed 15 pages (excluding the list of references), and the reference list should contain no more than 150 items.</li>
</ol>
<h3>Submission Procedure</h3>
<ol>
<li>Please visit: <a href="http://mc03.manuscriptcentral.com" target="_blank">http://mc03.manuscriptcentral.com</a> (ScholarOne Manuscripts System) and follow the instructions to upload your file. For the first submission, you need to register a new account.</li>
<li>Sign the Transfer of Copyright Agreement.</li>
<li>Upon successful submission, the author will receive an email acknowledging receipt of the submission and assigning a reference number.</li>
<li>The author can inquire about the review status via email. If any modifications are required, the author will be notified accordingly.</li>
</ol>
<h3>Peer Review</h3>
<p>All articles in this journal undergo a peer-review process. Each published article is reviewed by a minimum of two independent reviewers using a double-blind peer review process. The reviewers'' identities are not disclosed to the authors, and vice versa. All articles will be screened for plagiarism prior to acceptance.</p>
<h3>Final Paper</h3>
<ol>
<li>Instructions on preparing final papers (for accepted papers).</li>
<li>Copyright</li> 
Agreement All authors must sign the Transfer of Copyright Agreement before their paper can be published. This agreement allows the publisher to protect the copyrighted material while preserving the authors'' proprietary rights. Authors are responsible for obtaining permission from the copyright holder to reproduce any figures or other materials included in the paper for which copyright already exists.

<li>Template</li>
<a href="http://cdn.j-cpsi.com/template.docx" target="_blank">WORD Template</a>
&nbsp;
<a href="http://cdn.j-cpsi.com/template.zip" target="_blank">LaTex Template </a>
</ol>
<p>We appreciate your adherence to these guidelines and look forward to receiving your submission. Should you have any further inquiries, please do not hesitate to contact us.</p>

<p>Sincerely,</p>
<p>Journal of Cyber-Physical-Social Intelligence Editorial Team</p>
',	'author',	NULL,	'2023-03-02 12:37:30.312258');

DROP TABLE IF EXISTS "admin_invite";
DROP SEQUENCE IF EXISTS admin_invite_id_seq;
CREATE SEQUENCE admin_invite_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 9 CACHE 1;

CREATE TABLE "public"."admin_invite" (
    "id" bigint DEFAULT nextval('admin_invite_id_seq') NOT NULL,
    "email" character varying(200) NOT NULL,
    "article_id" bigint DEFAULT '0' NOT NULL,
    "status" smallint DEFAULT '0' NOT NULL,
    "updated_at" timestamp,
    "created_at" timestamp DEFAULT now() NOT NULL,
    CONSTRAINT "admin_invite_email_key" UNIQUE ("email"),
    CONSTRAINT "admin_invite_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

COMMENT ON TABLE "public"."admin_invite" IS '邀请用户';

COMMENT ON COLUMN "public"."admin_invite"."email" IS '邮箱';

COMMENT ON COLUMN "public"."admin_invite"."status" IS '状态';

COMMENT ON COLUMN "public"."admin_invite"."updated_at" IS '更新时间';

COMMENT ON COLUMN "public"."admin_invite"."created_at" IS '创建时间';

INSERT INTO "admin_invite" ("id", "email", "article_id", "status", "updated_at", "created_at") VALUES
(2,	'jwang@monmouth.edu',	22,	2,	NULL,	'2023-08-30 03:26:00.381993'),
(7,	'wangj1125@163.com',	11,	2,	NULL,	'2023-09-15 07:50:57.924486'),
(9,	'chunweitian@nwpu.edu.cn',	25,	2,	NULL,	'2023-09-15 07:56:56.012007'),
(6,	'vorsini@univpm.it	',	23,	2,	NULL,	'2023-09-15 07:46:08.844459'),
(1,	'minamoto@sina.com',	8,	2,	NULL,	'2023-08-30 02:32:36.826285'),
(5,	'qinhuafengfeng@163.com',	21,	2,	NULL,	'2023-09-15 07:35:17.075844');

DROP TABLE IF EXISTS "article";
DROP SEQUENCE IF EXISTS article_id_seq;
CREATE SEQUENCE article_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 43 CACHE 1;

CREATE TABLE "public"."article" (
    "id" bigint DEFAULT nextval('article_id_seq') NOT NULL,
    "doi" character varying(200),
    "title" text NOT NULL,
    "abstract" text NOT NULL,
    "graphic" text,
    "status" smallint DEFAULT '0',
    "early_access" boolean DEFAULT false,
    "issue_number" bigint DEFAULT '0',
    "html_link" character varying(200),
    "show_html" boolean DEFAULT true,
    "pdf_link" character varying(200),
    "pdf_size" integer DEFAULT '0',
    "read_count" integer DEFAULT '0',
    "citation_count" integer DEFAULT '0',
    "download_count" integer DEFAULT '0',
    "updated_at" timestamp,
    "created_at" timestamp DEFAULT now() NOT NULL,
    "keywords" character varying[] DEFAULT '{}' NOT NULL,
    "pdf_edition" character varying(200),
    CONSTRAINT "article_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "article" ("id", "doi", "title", "abstract", "graphic", "status", "early_access", "issue_number", "html_link", "show_html", "pdf_link", "pdf_size", "read_count", "citation_count", "download_count", "updated_at", "created_at", "keywords", "pdf_edition") VALUES
(3,	NULL,	'Research on Aircraft Image Recognition Based on Transfer Learning and Improved YOLOv5 Model',	'Effective differentiation of aircraft types using images is important for providing military combat information as well as civilian aircraft operations. Aircraft image recognition has many difficulties such as large variations of target scale, complex backgrounds, and difficult data set acquisition, which lead to the low recognition accuracy of existing models. To address the problem of low recognition accuracy caused by the above difficulties. This paper proposes the improved YOLOv5 model for the recognition of aircraft images. First, this paper designs the CSPResNet50dCA network as the backbone of the YOLOv5 model to enhance the feature extraction capability for small target aircraft in images. By introducing the coordinate attention mechanism and the CSP structure, the feature-focusing capability and the computing speed of the model are enhanced. Afterward, we use data enhancement to expand the data set and transfer learning to improve the generalization ability and convergence speed of the model, so as to improve its robustness. The experimental results show that the improved YOLOv5 model has significantly improved the recognition accuracy of aircraft targets， and significantly enhanced feature extraction ability for small target aircraft with good generalization ability',	NULL,	0,	'f',	0,	NULL,	't',	'2/Research on Aircraft Image Recognition Based on Transfer Learning and Improved YOLOv5 Model.pdf',	2082027,	0,	0,	0,	'2023-03-31 10:39:30.318058',	'2023-04-01 06:26:53.571441',	'{123}',	'2/edition4.pdf'),
(23,	'10.61702/VLZK2105',	'Designing a resilient supply chain through a robust adaptive model predictive control policy under  perishable goods and uncertain forecast information',	'We consider the inventory control problem for Supply Chains (SC) with deteriorating items and an uncertain future customer demand freely varying inside a given compact set. The problem is to deﬁne a resilient Replenishment Policy (RP) keeping the actual inventory level as close as possible to a desired reference trajectory. This requirement should be satisﬁed despite uncertainties on the decay factor of stocked goods and unexpected customer demand patterns outside the bounds of the compact set. We propose a method based on a Resilient Robust Model Predictive Control (RRMPC) approach. This requires dealing with a Min-Max Constrained Optimization Problem (MMCOP). To reduce the numerical complexity of the algorithm, the control signal is parametrized using B-spline functions.',	NULL,	10,	'f',	0,	NULL,	'f',	'12/designing_a_resilient_supply_chain_through_a_robust_adaptive_model_predictive_control_policy_under__perishable_goods_and_uncertain_forecast_information.pdf',	1592338,	13,	0,	17,	'2023-07-18 03:30:29.388538',	'2023-07-21 09:15:26.348158',	'{"supply chain","resilient robust model predictive control","min-max optimization","optimal inventory management"}',	'12/edition3.pdf'),
(4,	NULL,	'An Improved Tabu Search Algorithm for Multi-robot Hybrid Disassembly Line Balancing Problems',	'In recent years, the progress in the global industrialization process and the continuous advances in science and technology have brought great improvement to people''s living standards. The continuous expansion of manufacturing production has produced hundreds of millions of industrial wastes. Disassembly is one of the most effective ways to recycle wastes. Traditional manual disassembly incurs high cost and cause severe safety risks. In this paper, a hybrid disassembly line balancing problem based on different types of robots is addressed by combining the different advantages of a U-shaped disassembly line and a single-row disassembly line. A mathematical model is established to maximize the recovery profit. Based on an improved tabu search algorithm, two different neighborhoods are designed and the initial feasible solutions are obtained by using a greedy algorithm. Experimental results show that the near optimal solution obtained by the algorithm is better than the initial feasible solution in a short time for large-scale examples.',	NULL,	6,	'f',	0,	NULL,	'f',	'1/An Improved Tabu Search Algorithm for Multi-robot Hybrid Disassembly Line Balancing Problems.pdf',	923320,	24,	1,	30,	'2023-03-31 10:39:30.318058',	'2023-04-01 08:00:59.98981',	'{"improved tabu search algorithm","multi-robot disassembly","Hybrid disassembly line balancing problem"}',	NULL),
(6,	NULL,	'3D Multi-Angle Point Cloud Stitching Using Iterative Closest-point Stitching and K-Nearest-Neighbors',	'The recent focus on virtual environments and 3D object scanning has highlighted the need for accurate and efficient methods to stitch concurrent point clouds into solid three-dimensional (3D) models. To address this need, we introduce a novel iterative approach for 3D multi-angle point cloud stitching using an iterative closest point (ICP) algorithm augmented with k-nearest neighbors (kNN). With this combined algorithm, our method focuses on minimizing the error between neighboring point clouds, allowing us to easily compute the necessary transformation to combine point clouds into one model. Thus, when given concurrent point clouds captured at multiple angles of the same object, our approach provides a single accurate 3D model. We evaluated the ability of the proposed framework to stitch multiple point clouds into a solid model by stitching a segmented model and comparing the root mean squared error to a standard iterative closest-point stitching algorithm. The experiments results shows that our method provides benefits in terms of efficiency and accuracy compared to a standard approach.',	NULL,	6,	'f',	0,	NULL,	'f',	'1/3D Multi-Angle Point Cloud Stitching Using Iterative Closest-point Stitching and K-Nearest-Neighbors.pdf',	701365,	73,	1,	23,	'2023-04-01 11:30:13.608657',	'2023-04-01 11:38:20.477021',	'{"3D point clouds",kNN,ICP,"point-cloud stitching"}',	NULL),
(1,	NULL,	'DAO12',	'abstract22',	NULL,	5,	'f',	0,	NULL,	't',	'1/DAO.pdf',	43751,	0,	0,	0,	'2023-03-31 08:02:56.595328',	'2023-03-31 08:30:45.980042',	'{dao,"blocak chain"}',	NULL),
(5,	NULL,	'Stochastic Greedy Two-neighborhood Search Algorithm For Hybrid Disassembly Line Balancing Problem Considering Human Posture',	'With the continuous development of manufacturing industry, many waste products are produced as a side effect. Recycling these waste products can significantly improve the utilization of resources and promote the green development of the environment. Establishing a manual disassembly line is one way to recycle scrap, but the mixture of multiple disassembly lines can be more effective. This paper proposes a hybrid disassembly line balance problem that takes human posture into consideration. This problem combines the U -shaped and linear disassembly line features. We establish a mathematical model to obtain maximum profit, and propose to use the stochastic greedy two-neighborhood search algorithm can solve this problem. The algorithm searches different neighborhoods to obtain the near-optimal solution. The experimental results show that the algorithm can get a good solution.',	NULL,	6,	'f',	0,	NULL,	'f',	'1/Stochastic Greedy Two-neighborhood Search Algorithm For Hybrid Disassembly Line Balancing Problem Considering Human Posture.pdf',	591911,	36,	1,	26,	'2023-03-31 10:39:30.346277',	'2023-04-01 08:53:26.686317',	'{"simulated annealing","human posture","Hybrid disassembly line balance problem "}',	NULL),
(2,	NULL,	'A Feature Fusion Object Detector for Autonomous Driving in Mining Area',	'An accurate and reliable object detection is an important building block for the most autonomous driving system. Specially, in some scenarios like autonomous driving in the mining area, the detection of small and hard samples are a great challenges for perception system. In this paper, we propose a multi-scales fusion and attention-based model to improve the performance of the object detection for different scales and camouflaged obstacles in the mining area, like trucks, rocks, person and so on. Based on our proposed model, we have developed a new object detector, called FANet, which achieves much better efficiency than prior arts by using some optimization strategies. When we test the proposed model at our datasets, it can achieve 77.76 AP50 in 19 ms on a Titan X, compared to 68.16 AP50 in 22 ms by YOLOv3. The work has successfully apply in the autonomous driving system in mining area.',	NULL,	6,	'f',	0,	NULL,	'f',	'1/A Feature Fusion Object Detector for Autonomous Driving in Mining Area.pdf',	1193311,	104,	1,	55,	'2023-03-31 08:02:56.595328',	'2023-03-31 09:05:34.606195',	'{"object detection","surface mining","Autonomous vehicles"}',	NULL),
(8,	NULL,	'Research on Aircraft Image 2',	' Effective differentiation of aircraft types using images is important for providing military combat information as well as civilian aircraft operations. Aircraft image recognition has many difficulties such as large variations of target scale, complex backgrounds, and difficult data set acquisition, which lead to the low recognition accuracy of existing models. To address the problem of low recognition accuracy caused by the above difficulties. ',	NULL,	6,	'f',	0,	NULL,	't',	'1/research_on_aircraft_image.pdf',	2082027,	1,	0,	0,	'2023-05-29 11:25:34.648049',	'2023-05-29 11:31:18.747247',	'{data,image}',	'11/edition5.pdf'),
(42,	NULL,	'test09172023',	'test09172023',	NULL,	2,	'f',	0,	NULL,	't',	'2/test09172023.pdf',	1257643,	0,	0,	0,	'2023-09-15 08:42:13.991407',	'2023-09-18 00:54:49.003987',	'{test09172023}',	NULL),
(7,	NULL,	'Collide Detection, Reaction and Implementation for Excavator Arm',	'Collision detection and proper motion reaction strategy for avoiding the collision is a common problem for excavator arms to ensure the safety of the surrounding and itself. In this paper, a method consisting two parts with the implementation for the hydraulic excavator was proposed for this problem. Firstly, collision was detected based on forward kinematics of an excavator model. Secondly, ‘enabling filter’ was done for safe collision reaction, which indicate directions of joints of the arm that reduce collision. In the implementation part, an excavator was modified to support electric control and the use of above collision mechanism in such system is explained. Finally, field test was also carried out on this platform to prove its efficiency. Although this method is highlighted on excavator arms, it applies to common robotic arm.',	NULL,	6,	'f',	0,	NULL,	'f',	'1/Collide Detection, Reaction and Implementation for Excavator Arm.pdf',	1215498,	15,	0,	31,	'2023-04-01 11:30:13.608657',	'2023-04-01 11:54:19.635459',	'{"robotic arm","rigid body collision","excavator arm","collision detection"}',	NULL),
(9,	NULL,	'212',	'333333333333333333333',	NULL,	0,	'f',	0,	NULL,	't',	'3/212.pdf',	1848170,	0,	0,	0,	'2023-05-30 10:10:18.807177',	'2023-05-30 14:41:40.600966',	'{4444444444444}',	NULL),
(11,	'10.61702/GOPK6999',	'Research on Aircraft image recognition based on transfer learning and improved YOLOv5 model',	' Effective differentiation of aircraft types using images is important for providing military combat information as well as civilian aircraft operations. Aircraft image recognition has many difficulties such as large variations of target scale, complex backgrounds, and difficult data set acquisition, which lead to the low recognition accuracy of existing models. To address the problem of low recognition accuracy caused by the above difficulties. This paper proposes the improved YOLOv5 model for the recognition of aircraft images. First, this paper designs the CSPResNet50dCA network as the backbone of the YOLOv5 model to enhance the feature extraction capability for small target aircraft in images. By introducing the coordinate attention mechanism and the CSP structure, the feature-focusing capability and the computing speed of the model are enhanced. Afterward, we use data enhancement to expand the data set and transfer learning to improve the generalization ability and convergence speed of the model, so as to improve its robustness. The experimental results show that the improved YOLOv5 model has significantly improved the recognition accuracy of aircraft targets， and significantly enhanced feature extraction ability for small target aircraft with good generalization ability. ',	NULL,	10,	'f',	0,	NULL,	'f',	'9/journal_of_cyber-physical-social_intelligence_1.pdf',	2451927,	20,	0,	31,	'2023-07-06 02:56:55.391502',	'2023-07-10 04:17:07.218945',	'{" CSPResNet"," target detection"," attention mechanism"," aircraft recognition"," yolov","dCA  "}',	'9/edition4.pdf'),
(12,	NULL,	'Table of Contents',	'',	NULL,	21,	'f',	0,	NULL,	'f',	'1/table_of_contents.pdf',	287747,	4,	0,	2,	'2023-10-13 08:48:12.959508',	'2023-07-10 04:19:25.224425',	'{}',	NULL),
(13,	NULL,	' test123',	' test312',	NULL,	0,	'f',	0,	NULL,	't',	'5/_test.pdf',	1193311,	0,	0,	0,	'2023-07-06 02:56:55.391502',	'2023-07-10 04:31:20.226904',	'{1231," test"}',	NULL),
(25,	'10.61702/MTPG8588',	'A Diffusion Model with A FFT for Image Inpainting',	'Diffusion models for image inpainting have been the subject of growing research interest in recent years. However, generating content that is consistent with the original images, especially for complex images with intricate details and structural information, remains a significant challenge. In this paper, we propose a diffusion model with an FFT (FFT-DM) to generate content that matches missing region texture and semantics to inpaint damaged images. Specifically, FFT-DM contains two components: a Denoising Diffusion Probabilistic Model (DDPM) and a Convolutional Neural Network (CNN). The DDPM is used to extract global features and generate image prior while the CNN captures more fine-grained details and predicts the parameters in the reverse process of the diffusion model. Notably, we integrate a Fast Fourier Transform (FFT) into the diffusion model to enhance the perception ability and improve the efficiency of the model. Extensive experiments demonstrate that FFT-DM outperforms current state-of-the-art inpainting approaches in terms of qualitative and quantitative analysis. ',	NULL,	10,	'f',	0,	NULL,	'f',	'13/a_diffusion_model_with_a_fft_for_image_inpainting.pdf',	1259825,	20,	0,	11,	'2023-07-18 03:30:29.388538',	'2023-07-21 09:33:30.870582',	'{" Fast Fourier Transform"," Image Inpainting"," Convolutional Neural Network"," Diffusion model"}',	'13/edition6.pdf'),
(22,	'10.61702/BIQD5086',	'Discrete Bat Optimizer for Disassembly Line Balancing Problem',	'The recycling of end-of-life (EOL) products is the primary link in the remanufacturing process. EOL products rely on disassembly lines to retain valuable parts for remanufacturing. In this work, a disassembly line balancing model is established based on an AND/OR graph. It takes precedence relation, cycle time restriction, failure risk, and time uncertainty into consideration and aims to maximize the dismantling proﬁt and minimize the energy consumption. Then, a multi-objective discrete bat optimizer based on Pareto rules is designed according to the problem model, and a precedence preserving crossover operator, a single point mutation operator and a 2-optimization operator are used to simulate the ﬂight strategy of bats to satisfy the search of feasible solutions. To speed up the convergence, we propose an elite strategy to maintain the non-dominate solutions in the external ﬁles. By decomposing products of different sizes and analyzing the experimental results, the proposed algorithm is evaluated with the existing multi-objective discrete gray wolf optimizer, artiﬁcial bee colony optimizer, non-dominated sorting genetic algorithm II, and multi-objective evolutionary algorithm based on decomposition. The effectiveness of the proposed algorithm in solving this problem is veriﬁed.',	NULL,	10,	'f',	0,	NULL,	'f',	'11/discrete_bat_optimizer_for_disassembly_line_balancing_problem.pdf',	719466,	37,	0,	27,	'2023-07-18 03:30:29.340329',	'2023-07-21 09:06:35.604741',	'{"End-of-life products",remanufacturing,"precedence relation","disassembly line balancing","discrete bat algorithm","AND/OR graph",multi-objective}',	'11/edition2.pdf'),
(20,	NULL,	' 123',	'123',	NULL,	0,	'f',	0,	NULL,	't',	'5/_123.pdf',	1193311,	0,	0,	0,	'2023-07-10 05:03:00.967546',	'2023-07-10 23:40:44.025097',	'{123}',	NULL),
(43,	NULL,	' Journal of Cyber-Physical-Social Intelligence',	'',	NULL,	21,	'f',	0,	NULL,	'f',	'1/_journal_of_cyber-physical-social_intelligence.pdf',	723973,	8,	0,	4,	'2023-10-10 09:07:17.231153',	'2023-10-13 08:53:02.119772',	'{}',	NULL),
(10,	NULL,	'Thales YOLOv5 mini',	'Effective differentiation of aircraft types using images is important for providing military combat information as well as civilian aircraft operations. Aircraft image recognition has many difficulties such as large variations of target scale, complex backgrounds, and difficult data set acquisition, which lead to the low recognition accuracy of existing models. To address the problem of low recognition accuracy caused by the above difficulties. This paper proposes the improved YOLOv5 model for the recognition of aircraft images. First, this paper designs the CSPResNet50dCA network as the backbone of the YOLOv5 model to enhance the feature extraction capability for small target aircraft in images. By introducing the coordinate attention mechanism and the CSP structure, the feature-focusing capability and the computing speed of the model are enhanced. Afterward, we use data enhancement to expand the data set and transfer learning to improve the generalization ability and convergence speed of the model, so as to improve its robustness. The experimental results show that the improved YOLOv5 model has significantly improved the recognition accuracy of aircraft targets， and significantly enhanced feature extraction ability for small target aircraft with good generalization ability. ',	NULL,	5,	'f',	0,	NULL,	't',	'1/thales_yolov5.pdf',	2082027,	0,	0,	0,	'2023-07-04 09:53:35.065519',	'2023-07-04 10:04:16.900233',	'{" CSPResNet"," target detection"," yolov"," attention mechanism"}',	NULL),
(21,	'10.61702/YRMC5182',	'CGAN-DA: A Cross-Modality Domain Adaptation Model for Hand-Vein Biometric-based Authentication',	'Palm-vein recognition has been the focus of large research efforts over the last years.
However, despite the effectiveness of deep learning models, in particular Convolutional Neural Networks
(CNNs), in automatically learning robust feature representations, thereby obtaining good accuracy, such
good performance is usually obtained at the expense of annotating a large training dataset. Labeling vein
images, however, is an expensive and tedious process. Although handcrafted schemes for data augmentation
usually increase slightly performance, they are unable to cover complex variations inherently characterizing
such images. To overcome this issue, we propose a new unsupervised domain adaptation model, called
CycleGAN-based domain adaptation (CGAN-DA), that extracts discriminant representation from the palmvein
images, without requiring any image labeling. Our CGAN-DA models allows a conjoint adaptation,
at the image and feature levels. Specifically, in order to enhance the extracted features’ domain-invariance,
image appearance is transformed across two domains, palm-vein domain and retinal domain. We employ
several adversarial losses namely a segmentation loss and a cycle consistence loss to train our model without
any annotation from the target domain (palm-vein images). Our experiments on the public CASIA palm-vein
dataset demonstrates that our models significantly outperforms the s tart of the art in terms of verification
accuracy.',	NULL,	10,	'f',	0,	NULL,	'f',	'10/a.pdf',	1487911,	20,	0,	23,	'2023-07-18 03:30:29.388538',	'2023-07-21 08:35:26.44861',	'{"Palm-vein Authentication, Domain Adaptation, Generative adversarial network, Convolutional Neural Network."}',	'10/edition1.pdf'),
(24,	'10.61702/VLZK2105',	'An Improved Adaptive Genetic Algorithm for U-shaped Disassembly Line Balancing Problem Subject to Area Resource Constraint',	'The disassembly, recovery, and reuse of waste products are attracting more and more attention. It not only saves resources and protects the environment but also promotes economic development. In a disassembly process, the disassembly line balancing problem is one of the most important problems.At present, the consideration of the space area of workstations is relatively small, and the relatively large use of the area of workstations can also better reduce costs. Aiming at the balancing problem of u-shaped disassembly line, a single-objective optimization mathematical model with area constraints is established with the goal of maximizing proﬁts. In order to solve this problem, we refer to Adaptive Genetic Algorithm and improve its crossover and mutation operator. We adopt elite strategy to avoid premature convergence and improve the global search ability. Its effectiveness is proved by comparison with the optimization results of CPLEX. Experimental results also verify the feasibility of the proposed model and the superiority of the improved Adaptive Genetic Algorithm when solving large-scale instances over another algorithm. At the same time, the experimental results also verify the superiority and effectiveness of the improved Adaptive Genetic Algorithm algorithm by comparing with Random Search.',	NULL,	10,	'f',	0,	NULL,	'f',	'11/an_improved_adaptive_genetic_algorithm_for_u-shaped_disassembly_line_balancing_problem_subject_to_area_resource_constraint.pdf',	1397887,	33,	0,	35,	'2023-07-18 03:30:29.388538',	'2023-07-21 09:26:14.736035',	'{"Disassembly line balancing","U-shaped disassembly line","Adaptive genetic algorithm"}',	'11/edition5.pdf');

DROP TABLE IF EXISTS "article_author";
CREATE TABLE "public"."article_author" (
    "article_id" bigint DEFAULT '0' NOT NULL,
    "author_id" bigint DEFAULT '0' NOT NULL,
    "sequence" smallint DEFAULT '0',
    CONSTRAINT "article_author_pkey" PRIMARY KEY ("article_id", "author_id")
) WITH (oids = false);

COMMENT ON COLUMN "public"."article_author"."article_id" IS 'article表id';

COMMENT ON COLUMN "public"."article_author"."author_id" IS 'author表id';

COMMENT ON COLUMN "public"."article_author"."sequence" IS '作者顺序';

INSERT INTO "article_author" ("article_id", "author_id", "sequence") VALUES
(24,	8,	1),
(24,	10,	2),
(24,	36,	3),
(24,	34,	4),
(2,	1,	1),
(2,	2,	2),
(2,	3,	3),
(2,	4,	4),
(2,	5,	0),
(5,	12,	1),
(5,	13,	2),
(5,	8,	3),
(5,	9,	4),
(5,	10,	5),
(5,	11,	0),
(6,	16,	1),
(6,	17,	2),
(6,	11,	3),
(6,	18,	0),
(4,	6,	1),
(4,	7,	2),
(4,	8,	3),
(4,	9,	4),
(4,	10,	5),
(4,	11,	0),
(7,	2,	1),
(7,	19,	2),
(7,	20,	3),
(7,	3,	4),
(7,	5,	0),
(24,	37,	5),
(24,	9,	0),
(22,	8,	1),
(22,	10,	2),
(22,	34,	3),
(22,	35,	4),
(22,	9,	0),
(21,	46,	1),
(21,	47,	2),
(21,	49,	3),
(21,	48,	4),
(21,	31,	0),
(42,	39,	1),
(42,	33,	2),
(13,	5,	1),
(13,	2,	2),
(13,	1,	3),
(42,	23,	0),
(20,	24,	1),
(20,	23,	2),
(20,	27,	0),
(1,	2,	1),
(1,	5,	2),
(1,	12,	3),
(1,	3,	4),
(1,	11,	0),
(3,	24,	1),
(3,	22,	0),
(10,	6,	1),
(10,	3,	2),
(10,	2,	3),
(10,	21,	0),
(25,	41,	1),
(25,	44,	2),
(25,	42,	3),
(25,	43,	4),
(25,	33,	0),
(11,	28,	1),
(11,	40,	2),
(11,	39,	3),
(11,	30,	0),
(23,	45,	1),
(23,	32,	0),
(8,	38,	1),
(8,	11,	2),
(8,	21,	0);

DROP TABLE IF EXISTS "article_keyword";
CREATE TABLE "public"."article_keyword" (
    "article_id" bigint DEFAULT '0' NOT NULL,
    "keyword" character varying(100) DEFAULT '' NOT NULL,
    "sequence" smallint DEFAULT '0',
    CONSTRAINT "article_keyword_pkey" PRIMARY KEY ("article_id", "keyword")
) WITH (oids = false);

COMMENT ON TABLE "public"."article_keyword" IS '文章关键词';

COMMENT ON COLUMN "public"."article_keyword"."article_id" IS '文章id';

COMMENT ON COLUMN "public"."article_keyword"."keyword" IS '关键词';

COMMENT ON COLUMN "public"."article_keyword"."sequence" IS '关键词顺序';

INSERT INTO "article_keyword" ("article_id", "keyword", "sequence") VALUES
(5,	'Hybrid disassembly line balance problem',	1),
(5,	'simulated annealing',	2),
(5,	'human posture',	3),
(4,	'Hybrid disassembly line balancing problem',	1),
(4,	'improved tabu search algorithm',	2),
(4,	'multi-robot disassembly',	3),
(6,	'ICP',	1),
(6,	'kNN',	2),
(6,	'point-cloud stitching',	3),
(6,	'3D point clouds',	4),
(2,	'Autonomous vehicles',	1),
(2,	'object detection',	2),
(2,	'surface mining',	3),
(7,	'collision detection',	1),
(7,	'robotic arm',	2),
(7,	'rigid body collision',	3),
(7,	'excavator arm',	4);

DROP TABLE IF EXISTS "author";
DROP SEQUENCE IF EXISTS author_id_seq;
CREATE SEQUENCE author_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 20 CACHE 1;

CREATE TABLE "public"."author" (
    "id" bigint DEFAULT nextval('author_id_seq') NOT NULL,
    "email" character varying(200) NOT NULL,
    "first_name" character varying(200) NOT NULL,
    "last_name" character varying(200) NOT NULL,
    "updated_at" timestamp,
    "created_at" timestamp DEFAULT now() NOT NULL,
    "updated_user_id" bigint,
    "created_user_id" bigint,
    "orcid" character varying(200),
    CONSTRAINT "author_email_key" UNIQUE ("email"),
    CONSTRAINT "author_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

COMMENT ON COLUMN "public"."author"."email" IS '作者邮箱';

COMMENT ON COLUMN "public"."author"."first_name" IS '作者名';

COMMENT ON COLUMN "public"."author"."last_name" IS '作者姓';

INSERT INTO "author" ("id", "email", "first_name", "last_name", "updated_at", "created_at", "updated_user_id", "created_user_id", "orcid") VALUES
(1,	'renlc@xcmg.com',	'Liangcai',	'Ren',	NULL,	'2023-03-31 09:14:10.080104',	NULL,	NULL,	NULL),
(2,	'yangc@xcmg.com',	'Chao',	'Yang',	NULL,	'2023-03-31 09:15:08.111157',	NULL,	NULL,	NULL),
(3,	'ruiqi.song@ia.ac.cn',	'Ruiqi',	'Song',	NULL,	'2023-03-31 09:15:40.016576',	NULL,	NULL,	NULL),
(4,	'shichao.chen@ia.ac.cn',	'Shichao',	'Chen',	NULL,	'2023-03-31 09:15:58.620126',	NULL,	NULL,	NULL),
(5,	'aiyunfeng@ucas.ac.cn',	'Yunfeng',	'Ai',	NULL,	'2023-03-31 09:16:17.751755',	NULL,	NULL,	NULL),
(6,	'1137381848@qq.com',	'Shiqi',	'Zhang',	NULL,	'2023-04-01 08:19:21.467607',	NULL,	NULL,	NULL),
(7,	'lps_1981@sina.com',	'Peisheng',	'Liu',	NULL,	'2023-04-01 08:19:56.054895',	NULL,	NULL,	NULL),
(11,	'tang@rowan.edu',	'Ying',	'Tang',	NULL,	'2023-04-01 08:23:05.339404',	NULL,	NULL,	NULL),
(12,	'1833299046@qq.com',	'Peng',	'Ji',	NULL,	'2023-04-01 08:54:35.360174',	NULL,	NULL,	NULL),
(13,	'wangxu@hebuee.edu.cn',	'Xu',	'Wang',	NULL,	'2023-04-01 08:56:18.923597',	NULL,	NULL,	NULL),
(16,	'pankti2047@gmail.com',	'Pankti',	'Patel',	NULL,	'2023-04-01 11:39:49.404455',	NULL,	NULL,	NULL),
(17,	'harer6@rowan.edu',	'Ryan',	'Hare',	NULL,	'2023-04-01 11:40:09.389521',	NULL,	NULL,	NULL),
(18,	'patelnidhig1@gmail.com',	'Nidhi',	'Patel',	NULL,	'2023-04-01 11:40:41.966738',	NULL,	NULL,	NULL),
(19,	'mahx@xcmg.com',	'Houxue',	'Ma',	NULL,	'2023-04-01 12:17:33.54141',	NULL,	NULL,	NULL),
(20,	'zhaob@xcmg.com',	'Bin',	'Zhao',	NULL,	'2023-04-01 12:17:55.559452',	NULL,	NULL,	NULL),
(45,	'b.ietto@univpm.it',	'Beatrice ',	'Ietto',	'2023-09-19 12:29:49.023696',	'2023-09-19 12:29:49.021973',	NULL,	NULL,	'0000-0001-5617-8228'),
(21,	'minamoto@sina.com',	'Tai',	'Jiang',	'2023-06-12 14:15:57.531518',	'2023-06-12 14:15:57.529933',	1,	NULL,	NULL),
(22,	'zhuche95@students.rowan.edu',	'Chengzhang',	'Zhu',	'2023-07-10 03:47:08.614017',	'2023-07-10 03:47:08.613092',	NULL,	NULL,	NULL),
(23,	'c137985990@gmail.com',	'luobin ',	'cui',	'2023-07-10 03:55:48.420916',	'2023-07-10 03:55:48.419993',	2,	NULL,	NULL),
(24,	'c137985990@qq.com',	'llll',	'ccc',	'2023-07-10 04:01:00.491404',	'2023-07-10 04:01:00.4905',	NULL,	NULL,	NULL),
(27,	'cuiluo77@students.rowan.edu',	'test',	'test',	'2023-07-10 04:06:09.720326',	'2023-07-10 04:06:09.718824',	NULL,	NULL,	NULL),
(28,	'yhy@njust.edu.cn',	'Huanyu',	'Yang',	'2023-07-10 07:30:18.705223',	'2023-07-10 07:30:18.704023',	NULL,	NULL,	NULL),
(35,	'hfgedu@163.com',	'Fuguang',	'Huang',	'2023-07-21 12:02:56.299408',	'2023-07-21 12:02:56.298438',	NULL,	NULL,	NULL),
(36,	'qiliangsdkd@163.com',	'Liang',	'Qi',	'2023-07-21 12:04:06.746012',	'2023-07-21 12:04:06.744815',	NULL,	NULL,	NULL),
(37,	'1194058368@qq.com',	'Weishuang',	'Bai',	'2023-07-21 12:10:46.418264',	'2023-07-21 12:10:46.417094',	NULL,	NULL,	NULL),
(38,	'19181170@qq.com',	'Thales',	'Jiang',	'2023-07-28 02:37:18.046481',	'2023-07-28 02:37:18.045464',	NULL,	NULL,	NULL),
(40,	'2369089426@qq.com',	'Lijun',	'Yang',	'2023-09-17 07:19:00.748878',	'2023-09-17 07:19:00.746004',	NULL,	NULL,	NULL),
(30,	'wangj1125@163.com',	'Jun',	'Wang',	'2023-07-21 06:38:48.152226',	'2023-07-21 06:38:48.151391',	9,	NULL,	NULL),
(39,	'byming@mail.njust.edu.cn',	'Yuming',	'Bo',	'2023-09-17 07:16:35.94749',	'2023-09-17 07:16:35.946615',	9,	NULL,	NULL),
(41,	'hyx_08@csu.edu.cn',	'Yuxuan',	'Hu',	'2023-09-19 07:48:47.65757',	'2023-09-19 07:48:47.656675',	NULL,	NULL,	NULL),
(33,	'chunweitian@nwpu.edu.cn',	'Chunwei',	'Tian',	'2023-07-21 09:30:48.273854',	'2023-07-21 09:30:48.273015',	13,	NULL,	NULL),
(42,	'jincong@cuc.edu.cn',	'Cong',	'Jin',	'2023-09-19 08:24:34.591169',	'2023-09-19 08:24:34.590277',	NULL,	NULL,	NULL),
(43,	'libo803@nwpu.edu.cn',	'Bo',	'Li',	'2023-09-19 08:26:32.525674',	'2023-09-19 08:26:32.524205',	NULL,	NULL,	NULL),
(44,	'hantingwang2001@163.com',	'Hanting',	'Wang',	'2023-09-19 08:29:22.456056',	'2023-09-19 08:29:22.455158',	NULL,	NULL,	NULL),
(46,	'19321364@qq.com',	'Shuqiang',	'Yang',	'2023-09-25 14:52:13.115619',	'2023-09-25 14:52:13.113183',	NULL,	NULL,	NULL),
(47,	'wuyiquan_cq@163.com',	'Yiquan',	'Wu',	'2023-09-25 14:53:11.831969',	'2023-09-25 14:53:11.831096',	NULL,	NULL,	NULL),
(49,	'158398730@qq.com',	'Xin',	'Jin',	'2023-09-25 15:01:11.954813',	'2023-09-25 15:01:11.953416',	NULL,	NULL,	NULL),
(10,	'sjchin@vip.126.com',	'Shujin',	'Qin',	NULL,	'2023-04-01 08:22:15.68868',	NULL,	NULL,	'0000-0002-4578-2726'),
(8,	'x.w.guo@163.com',	'XiWang',	'Guo',	NULL,	'2023-04-01 08:21:08.155657',	NULL,	NULL,	'0000-0002-9142-1251'),
(34,	'qizhang@syuct.edu.cn',	'Qi',	'Zhang',	'2023-07-21 12:02:05.713729',	'2023-07-21 12:02:05.712887',	NULL,	NULL,	'0000-0003-4518-4889'),
(9,	'jwang@monmouth.edu',	'Jiacun',	'Wang',	NULL,	'2023-04-01 08:21:43.755373',	11,	NULL,	'0000-0001-6601-3515'),
(31,	'qinhuafengfeng@163.com',	'Huafeng',	'Qin',	'2023-07-21 08:25:28.563519',	'2023-07-21 08:25:28.562553',	10,	NULL,	'0000-0003-4911-0393'),
(48,	'mounim.el_yacoubi@telecom-sudparis.eu',	'Mounim',	'el yacoubi',	'2023-09-25 14:54:57.946585',	'2023-09-25 14:54:57.944899',	NULL,	NULL,	'0000-0002-7383-0588'),
(32,	'vorsini@univpm.it',	'Valentina',	'Orsini',	'2023-07-21 09:11:14.658118',	'2023-07-21 09:11:14.657136',	12,	NULL,	'0000-0003-4965-5262');

DROP TABLE IF EXISTS "author_institution";
CREATE TABLE "public"."author_institution" (
    "author_id" bigint DEFAULT '0' NOT NULL,
    "institution_id" bigint DEFAULT '0' NOT NULL,
    "sequence" smallint DEFAULT '0',
    CONSTRAINT "author_institution_pkey" PRIMARY KEY ("author_id", "institution_id")
) WITH (oids = false);

COMMENT ON TABLE "public"."author_institution" IS '作者的机构';

COMMENT ON COLUMN "public"."author_institution"."author_id" IS 'author表id';

COMMENT ON COLUMN "public"."author_institution"."institution_id" IS 'institution表id';

COMMENT ON COLUMN "public"."author_institution"."sequence" IS '作者顺序';

INSERT INTO "author_institution" ("author_id", "institution_id", "sequence") VALUES
(21,	1,	0),
(21,	2,	0),
(22,	3,	0),
(23,	4,	0),
(28,	5,	0),
(31,	6,	0),
(9,	7,	0),
(32,	8,	0),
(33,	9,	0),
(30,	10,	0),
(33,	11,	0);

DROP TABLE IF EXISTS "institution";
DROP SEQUENCE IF EXISTS institution_id_seq;
CREATE SEQUENCE institution_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."institution" (
    "id" bigint DEFAULT nextval('institution_id_seq') NOT NULL,
    "institution" character varying(200) DEFAULT '' NOT NULL,
    "department" character varying(200),
    "address" character varying(200) DEFAULT '',
    "country" character varying(200),
    "province" character varying(200),
    "city" character varying(200),
    "postal_code" character varying(50),
    "phone" character varying(50) DEFAULT '',
    "fax" character varying(50),
    "updated_at" timestamp,
    "created_at" timestamp DEFAULT now() NOT NULL,
    CONSTRAINT "institution_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

COMMENT ON COLUMN "public"."institution"."institution" IS '机构';

COMMENT ON COLUMN "public"."institution"."department" IS '部门';

COMMENT ON COLUMN "public"."institution"."address" IS '地址';

COMMENT ON COLUMN "public"."institution"."country" IS '国家';

COMMENT ON COLUMN "public"."institution"."province" IS '省份';

COMMENT ON COLUMN "public"."institution"."city" IS '城市';

COMMENT ON COLUMN "public"."institution"."postal_code" IS '邮编';

COMMENT ON COLUMN "public"."institution"."phone" IS '电话';

COMMENT ON COLUMN "public"."institution"."fax" IS '传真';

INSERT INTO "institution" ("id", "institution", "department", "address", "country", "province", "city", "postal_code", "phone", "fax", "updated_at", "created_at") VALUES
(1,	'casia',	'sklmcc',	'xierqi1road',	'Chinae',	'Beijing',	'Haidian',	'100085',	'13810935087',	'82439824',	'2023-06-12 14:14:26.92254',	'2023-06-12 14:15:57.529933'),
(2,	'a',	'b',	'c',	'd',	'e',	'f',	'g',	'h',	'i',	'2023-06-12 14:14:27.042199',	'2023-06-13 01:16:47.682004'),
(3,	'Rowan University',	'ECE',	'',	'United States',	'New Jersey',	'Glassboro',	'08028',	'',	'',	'2023-07-06 02:56:55.391502',	'2023-07-10 03:47:08.613092'),
(4,	'123',	'123',	'123',	'123',	'123',	'123',	'123',	'123',	'123',	'2023-07-06 02:56:55.3836',	'2023-07-10 03:56:22.141902'),
(5,	'Nanjing University of Science and Technology',	'School of Automation',	'200 Xiaolingwei, Xuanwu District, Nanjing City, Jiangsu Province, China',	'China',	'Jiangsu',	'Nanjing',	'210094',	'',	'',	'2023-07-10 05:03:00.967546',	'2023-07-10 07:30:18.704023'),
(6,	'Chongqing Technology and Business University',	'The Chongqing Key Laboratory of Intelligent Perception and BlockChain Technology',	NULL,	'China',	'Chongqing',	'Chongqing',	'400067',	NULL,	NULL,	'2023-07-18 03:30:29.388538',	'2023-07-21 08:32:52.59127'),
(7,	'Sci. and Soft. Eng. at Monmouth University',	'Dept of Comp',	'W. Long Branch, NJ',	'USA',	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-18 03:30:29.388538',	'2023-07-21 08:59:10.139518'),
(8,	'Universita’ Politecnica delle Marche',	'Department of Information Engineering',	NULL,	'Italy',	'',	'Ancona',	NULL,	NULL,	NULL,	'2023-07-18 03:30:29.388538',	'2023-07-21 09:12:45.347281'),
(10,	'Nanjing University of Science and Technology',	'School of Automation',	'200 Xiaolingwei, Xuanwu District, Nanjing City, Jiangsu Province,China',	'China',	'Jiangsu',	'Nanjing',	'210094',	NULL,	NULL,	'2023-09-15 08:42:14.049004',	'2023-09-17 07:31:01.699771'),
(11,	'Northwestern Polytechnical University',	'Research & Development Institute',	NULL,	'China',	'Guangzhou',	'Shenzhen',	'518057',	NULL,	NULL,	'2023-09-18 15:52:12.382558',	'2023-09-19 08:09:02.610041'),
(9,	'Northwestern Polytechnical University',	'School of Software',	NULL,	'China',	'Shaanxi',	' Xi''an',	'710129',	NULL,	NULL,	'2023-07-18 03:30:29.340329',	'2023-07-21 09:31:30.914593');

DROP TABLE IF EXISTS "issue";
DROP SEQUENCE IF EXISTS issue_id_seq;
CREATE SEQUENCE issue_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."issue" (
    "id" bigint DEFAULT nextval('issue_id_seq') NOT NULL,
    "number" integer DEFAULT '0' NOT NULL,
    "cover" text,
    "year" smallint NOT NULL,
    "date" date,
    "editorial_message" text,
    "updated_at" timestamp,
    "created_at" timestamp DEFAULT now() NOT NULL,
    "volume" integer DEFAULT '0' NOT NULL,
    "name" character varying(200) DEFAULT '' NOT NULL,
    CONSTRAINT "issue_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

COMMENT ON COLUMN "public"."issue"."number" IS '编号';

COMMENT ON COLUMN "public"."issue"."cover" IS '封面';

COMMENT ON COLUMN "public"."issue"."year" IS '年';

COMMENT ON COLUMN "public"."issue"."date" IS '日期';

INSERT INTO "issue" ("id", "number", "cover", "year", "date", "editorial_message", "updated_at", "created_at", "volume", "name") VALUES
(1,	1,	'http://cdn.j-cpsi.com/cover/2023.jpg',	2022,	'2022-12-01',	'Editorial Message',	NULL,	'2023-04-01 02:00:57.810066',	1,	'Journal of Cyber-Physical-Social Intelligence');

DROP TABLE IF EXISTS "issue_article";
CREATE TABLE "public"."issue_article" (
    "issue_id" bigint NOT NULL,
    "article_id" bigint NOT NULL,
    "sequence" smallint DEFAULT '0' NOT NULL,
    "page_start" integer DEFAULT '0' NOT NULL,
    "page_end" integer DEFAULT '0' NOT NULL,
    CONSTRAINT "issue_article_pkey" PRIMARY KEY ("issue_id", "article_id")
) WITH (oids = false);

COMMENT ON COLUMN "public"."issue_article"."issue_id" IS 'issue表id';

COMMENT ON COLUMN "public"."issue_article"."article_id" IS 'article表id';

COMMENT ON COLUMN "public"."issue_article"."sequence" IS '文章顺序';

INSERT INTO "issue_article" ("issue_id", "article_id", "sequence", "page_start", "page_end") VALUES
(1,	12,	1,	0,	0),
(1,	43,	2,	1,	2),
(1,	21,	11,	3,	12),
(1,	22,	12,	13,	25),
(1,	23,	13,	26,	34),
(1,	11,	14,	35,	46),
(1,	24,	15,	47,	59),
(1,	25,	16,	60,	69);

DROP TABLE IF EXISTS "user";
DROP SEQUENCE IF EXISTS user_id_seq;
CREATE SEQUENCE user_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 14 CACHE 1;

CREATE TABLE "public"."user" (
    "id" bigint DEFAULT nextval('user_id_seq') NOT NULL,
    "email" character varying(200) NOT NULL,
    "password" character varying(200) NOT NULL,
    "author_id" bigint,
    "is_admin" boolean DEFAULT false,
    "is_active" boolean DEFAULT false,
    "updated_at" timestamp,
    "created_at" timestamp DEFAULT now() NOT NULL,
    CONSTRAINT "user_email_key" UNIQUE ("email"),
    CONSTRAINT "user_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

COMMENT ON COLUMN "public"."user"."email" IS '注册邮箱';

COMMENT ON COLUMN "public"."user"."password" IS '密码';

COMMENT ON COLUMN "public"."user"."author_id" IS '作者id';

COMMENT ON COLUMN "public"."user"."is_admin" IS '是否管理员';

COMMENT ON COLUMN "public"."user"."is_active" IS '是否激活';

COMMENT ON COLUMN "public"."user"."updated_at" IS '更新时间';

COMMENT ON COLUMN "public"."user"."created_at" IS '创建时间';

INSERT INTO "user" ("id", "email", "password", "author_id", "is_admin", "is_active", "updated_at", "created_at") VALUES
(3,	'sevtep0v0@gmail.com',	'$2b$12$6vOtSMfsG6AU/F4/WDfEsu0uW6FDyYLUTL7XOsC4G/PromKSBcXBq',	NULL,	'f',	't',	'2023-07-10 03:43:45.334945',	'2023-07-10 03:43:45.076294'),
(4,	'zhuche95@students.rowan.edu',	'$2b$12$lQlyScVkPGFIrNrDN9pjA.0mBPUjST1zaJg9iYVuLMelqsKB7dhtK',	22,	'f',	't',	'2023-07-10 03:46:01.003407',	'2023-07-10 03:46:00.743139'),
(2,	'c137985990@gmail.com',	'$2b$12$pd23Fp6ABBpNOiMXPdbgNexBbTghEMdNaT7ekpFcNpTJe3AZ8r266',	23,	'f',	't',	'2023-07-10 03:39:39.796321',	'2023-07-10 03:39:39.512886'),
(5,	'cuiluo77@students.rowan.edu',	'$2b$12$he1wHBK8W/x8IJ13Fi/DC.ojiKv8P5mN6X5rx36k1uXBodm0RpVtu',	27,	'f',	't',	'2023-07-10 04:03:24.012174',	'2023-07-10 04:03:23.727985'),
(6,	'yhy@njust.edu.cn',	'$2b$12$osyR7qUCc607BD0MflEiEOZAOWqhy8SvxIN/gHwiESivwmrP9XM02',	28,	'f',	't',	'2023-07-10 07:24:49.385759',	'2023-07-10 07:24:49.102018'),
(9,	'wangj1125@163.com',	'$2b$12$hHFS2L2c1KQYKrAXcBEmWeEgmuSaXUT4IYoC1dmQ0Caky9GyJOlzG',	30,	'f',	't',	'2023-07-21 06:38:22.594646',	'2023-07-21 06:38:22.331047'),
(10,	'qinhuafengfeng@163.com',	'$2b$12$WN3O2r82x3RR349iXNrKF.U96wRWb19IM189LoblT3oTilPT/y2Ie',	31,	'f',	't',	'2023-07-21 08:16:48.600383',	'2023-07-21 08:16:48.33645'),
(11,	'jwang@monmouth.edu',	'$2b$12$HwAI/6WDZsCrMhEK/ueJvOXj4H9gjQE4u88eYAYdtdfcJtx7C7DtW',	9,	'f',	't',	'2023-07-21 08:48:41.48726',	'2023-07-21 08:48:41.225466'),
(12,	'vorsini@univpm.it',	'$2b$12$tsfNpJH.eoZLhRA6Cob5POIsOM0M6i3Hgz1Ds7qol1qLzIkgMgFHO',	32,	'f',	't',	'2023-07-21 09:10:55.009412',	'2023-07-21 09:10:54.725225'),
(14,	'19181170@qq.com',	'$2b$12$IvM9tKFA4MUDJ0ml.aiHF.QFPIAQqlOIMrTByS6LfpM8j6Mfm99Fm',	38,	'f',	't',	'2023-07-28 02:38:33.919971',	'2023-07-28 02:38:33.635767'),
(13,	'chunweitian@nwpu.edu.cn',	'$2b$12$YRAdcxWc8rHxipBeLvIfa.ozlcfEj2H88UHwbMnZv5rFZ/AgUNdUK',	33,	'f',	't',	'2023-07-21 09:30:21.365529',	'2023-07-21 09:30:21.105785'),
(1,	'minamoto@sina.com',	'$2b$12$alNnd5ui1P4/xc8UpoPq2OTPTc1EzCFS86joTt8OSSqu/FjW4Wcs6',	21,	't',	't',	'2023-06-12 14:06:05.43459',	'2023-06-12 14:06:05.142517');

DROP TABLE IF EXISTS "user_article";
DROP SEQUENCE IF EXISTS user_article_id_seq;
CREATE SEQUENCE user_article_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 21 CACHE 1;

CREATE TABLE "public"."user_article" (
    "id" bigint DEFAULT nextval('user_article_id_seq') NOT NULL,
    "user_id" bigint DEFAULT '0' NOT NULL,
    "article_id" bigint DEFAULT '0' NOT NULL,
    "updated_at" timestamp,
    "created_at" timestamp DEFAULT now() NOT NULL,
    CONSTRAINT "user_article_pkey" PRIMARY KEY ("user_id", "article_id")
) WITH (oids = false);

COMMENT ON TABLE "public"."user_article" IS '用户发表文章';

COMMENT ON COLUMN "public"."user_article"."user_id" IS '用户id';

COMMENT ON COLUMN "public"."user_article"."article_id" IS '文章id';

INSERT INTO "user_article" ("id", "user_id", "article_id", "updated_at", "created_at") VALUES
(1,	1,	1,	'2023-03-31 08:02:56.611262',	'2023-03-31 08:30:45.984303'),
(2,	1,	2,	'2023-03-31 08:02:56.611262',	'2023-03-31 09:05:34.608463'),
(4,	1,	4,	'2023-03-31 10:39:30.323797',	'2023-04-01 08:00:59.992256'),
(5,	1,	5,	'2023-03-31 10:39:30.354025',	'2023-04-01 08:53:26.690372'),
(6,	1,	6,	'2023-04-01 11:30:13.616357',	'2023-04-01 11:38:20.480639'),
(7,	1,	7,	'2023-04-01 11:30:13.616357',	'2023-04-01 11:54:19.638014'),
(8,	1,	8,	'2023-05-29 11:25:34.648049',	'2023-05-29 11:31:18.747247'),
(9,	3,	9,	'2023-05-30 10:10:18.807177',	'2023-05-30 14:41:40.600966'),
(10,	1,	10,	NULL,	'2023-07-04 10:04:16.900233'),
(12,	1,	12,	NULL,	'2023-07-10 04:19:25.224425'),
(13,	5,	13,	NULL,	'2023-07-10 04:31:20.226904'),
(14,	5,	20,	NULL,	'2023-07-10 23:40:44.025097'),
(11,	9,	11,	NULL,	'2023-07-10 04:17:07.218945'),
(15,	10,	21,	NULL,	'2023-07-21 08:35:26.44861'),
(16,	11,	22,	NULL,	'2023-07-21 09:06:35.604741'),
(17,	12,	23,	NULL,	'2023-07-21 09:15:26.348158'),
(18,	11,	24,	NULL,	'2023-07-21 09:26:14.736035'),
(19,	13,	25,	NULL,	'2023-07-21 09:33:30.870582'),
(3,	2,	3,	'2023-03-31 10:39:30.323797',	'2023-04-01 06:26:53.575247'),
(20,	2,	42,	NULL,	'2023-09-18 00:54:49.003987'),
(21,	1,	43,	NULL,	'2023-10-13 08:53:02.119772');

DROP TABLE IF EXISTS "user_article_audition";
DROP SEQUENCE IF EXISTS user_article_audition_id_seq;
CREATE SEQUENCE user_article_audition_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1;

CREATE TABLE "public"."user_article_audition" (
    "id" bigint DEFAULT nextval('user_article_audition_id_seq') NOT NULL,
    "user_id" bigint DEFAULT '0' NOT NULL,
    "article_id" bigint DEFAULT '0' NOT NULL,
    "status" smallint DEFAULT '0' NOT NULL,
    "message" text,
    "origin_id" bigint,
    "updated_at" timestamp,
    "created_at" timestamp DEFAULT now() NOT NULL,
    CONSTRAINT "user_article_audition_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "user_article_audition" ("id", "user_id", "article_id", "status", "message", "origin_id", "updated_at", "created_at") VALUES
(1,	1,	42,	2,	'aqaqa',	NULL,	'2023-10-05 08:11:05.653455',	'2023-10-10 01:52:51.559396');

ALTER TABLE ONLY "public"."admin_invite" ADD CONSTRAINT "admin_invite_article_id_fkey" FOREIGN KEY (article_id) REFERENCES article(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."article_author" ADD CONSTRAINT "article_author_article_id_fkey" FOREIGN KEY (article_id) REFERENCES article(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."article_author" ADD CONSTRAINT "article_author_author_id_fkey" FOREIGN KEY (author_id) REFERENCES author(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."article_keyword" ADD CONSTRAINT "article_keyword_article_id_fkey" FOREIGN KEY (article_id) REFERENCES article(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."issue_article" ADD CONSTRAINT "issue_article_article_id_fkey" FOREIGN KEY (article_id) REFERENCES article(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."issue_article" ADD CONSTRAINT "issue_article_issue_id_fkey" FOREIGN KEY (issue_id) REFERENCES issue(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."user" ADD CONSTRAINT "user_author_id_fkey" FOREIGN KEY (author_id) REFERENCES author(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."user_article" ADD CONSTRAINT "user_article_article_id_fkey" FOREIGN KEY (article_id) REFERENCES article(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."user_article" ADD CONSTRAINT "user_article_user_id_fkey" FOREIGN KEY (user_id) REFERENCES "user"(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."user_article_audition" ADD CONSTRAINT "user_article_audition_article_id_fkey" FOREIGN KEY (article_id) REFERENCES article(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."user_article_audition" ADD CONSTRAINT "user_article_audition_origin_fkey" FOREIGN KEY (origin_id) REFERENCES user_article_audition(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

-- 2023-11-06 13:04:30.148169+00
